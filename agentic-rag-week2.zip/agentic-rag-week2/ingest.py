from agent.config import DOCS_DIR, CHUNK_SIZE, CHUNK_OVERLAP
from agent.document_loader import load_documents
from agent.chunker import chunk_text
from agent.vector_store import VectorStore

def main():
    print("=" * 66)
    print("AGENTIC RAG — DOCUMENT INGESTION")
    print("=" * 66)
    docs = load_documents(DOCS_DIR)
    if not docs:
        print(f"[ERROR] No .md or .txt documents found in {DOCS_DIR}")
        return
    items = []
    for doc in docs:
        for idx, chunk in enumerate(chunk_text(doc["text"], CHUNK_SIZE, CHUNK_OVERLAP)):
            items.append({
                "id": f"{doc['source']}::chunk-{idx}",
                "source": doc["source"], "chunk_index": idx, "text": chunk
            })
    store = VectorStore()
    store.reset()
    store.add(items)
    print(f"Documents loaded : {len(docs)}")
    print(f"Chunks indexed   : {len(items)}")
    print(f"Chunk size       : {CHUNK_SIZE} words")
    print(f"Chunk overlap    : {CHUNK_OVERLAP} words")
    print(f"Stored locally   : {store.collection.count()} chunks")
    print("[SUCCESS] Index built. Run `python main.py`.")

if __name__ == "__main__":
    main()
