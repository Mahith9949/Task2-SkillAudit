# ChromaDB Vector Storage
ChromaDB stores embeddings, document text, and metadata. In persistent local mode, data is saved to a folder on the computer and no separate vector database server is required.

For a RAG application, the query embedding is compared with stored chunk embeddings. The top-k closest chunks are returned as context. Source filenames and chunk indexes can be stored as metadata.
