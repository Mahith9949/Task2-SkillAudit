# RAG Basics
Retrieval-Augmented Generation (RAG) combines information retrieval with language-model generation. A RAG application searches a document collection and supplies relevant passages to a language model to help answer questions from the collection.

A typical pipeline loads documents, splits text into chunks, creates embeddings, stores vectors, retrieves relevant chunks for a question, checks the evidence, and generates a grounded answer. Retrieval quality strongly influences answer quality.
