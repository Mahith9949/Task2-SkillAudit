# Embeddings
An embedding is a numerical vector representing the semantic content of text. Sentence Transformers can create embeddings locally. The all-MiniLM-L6-v2 model is a compact model often used for semantic search.

A question is embedded with the same model used for document chunks. The vector database finds chunks whose vectors are similar to the question vector.
