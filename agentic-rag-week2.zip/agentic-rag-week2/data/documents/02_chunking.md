# Chunking and Overlap
Chunking divides long documents into smaller passages. Overlap repeats some words from the end of one chunk at the beginning of the next. An overlap around 50 words can preserve context near chunk boundaries.

Very large chunks can include unrelated information. Tiny chunks can lose context. Chunk size and overlap should be tested with representative questions and documents.
