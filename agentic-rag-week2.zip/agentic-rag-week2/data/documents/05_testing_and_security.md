# Self-Checking, Testing, and API Security
A self-check step judges whether retrieved passages contain enough evidence to answer a question. If evidence is weak or missing, an agent can rewrite the query with different keywords and retrieve again. A simple system may retry up to two times and log each decision.

Test both questions that are answered by the documents and questions that are not covered. When evidence is missing, the system should say it cannot find the answer instead of inventing facts.

Hosted language-model APIs usually require an API key and internet access. Keep API keys in a local .env file and never commit secrets to a public repository.
