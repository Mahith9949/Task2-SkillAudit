from agent.config import LLM_PROVIDER, GEMINI_API_KEY, GEMINI_MODEL

def ask_llm(prompt: str) -> str:
    """Use Gemini when configured; otherwise return an explicit demo-mode signal."""
    if LLM_PROVIDER == "demo":
        return ""
    if LLM_PROVIDER != "gemini":
        raise ValueError("LLM_PROVIDER must be 'demo' or 'gemini'.")
    if not GEMINI_API_KEY:
        raise RuntimeError("GEMINI_API_KEY is missing in .env.")
    from google import genai
    client = genai.Client(api_key=GEMINI_API_KEY)
    response = client.models.generate_content(model=GEMINI_MODEL, contents=prompt)
    return (response.text or "").strip()
