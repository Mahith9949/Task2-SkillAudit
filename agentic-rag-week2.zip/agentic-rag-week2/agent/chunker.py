import re

def chunk_text(text: str, size: int = 350, overlap: int = 50) -> list[str]:
    if size < 1 or overlap < 0 or overlap >= size:
        raise ValueError("Chunk size must be > 0 and overlap must be >= 0 and < size.")
    words = re.findall(r"\\S+", text)
    if not words:
        return []
    step = size - overlap
    result = []
    for start in range(0, len(words), step):
        result.append(" ".join(words[start:start + size]))
        if start + size >= len(words):
            break
    return result
