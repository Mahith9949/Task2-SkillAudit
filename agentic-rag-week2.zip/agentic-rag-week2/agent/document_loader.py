from pathlib import Path

def load_documents(directory: Path) -> list[dict]:
    directory.mkdir(parents=True, exist_ok=True)
    records = []
    for path in sorted(directory.rglob("*")):
        if path.is_file() and path.suffix.lower() in {".txt", ".md"}:
            text = path.read_text(encoding="utf-8", errors="replace").strip()
            if text:
                records.append({"source": path.relative_to(directory).as_posix(), "text": text})
    return records
