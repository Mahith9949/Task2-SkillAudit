from agent.config import LLM_PROVIDER
from agent.llm import ask_llm

def rewrite_query(question: str, attempt: int) -> str:
    if LLM_PROVIDER == "gemini":
        try:
            prompt = f"""Rewrite this search query to retrieve better evidence from technical project notes.
Keep it concise and include likely synonyms. Return only the rewritten query.
Original question: {question}
Retry number: {attempt}"""
            result = ask_llm(prompt)
            if result:
                return result.strip().strip('"')
        except Exception:
            pass
    # Deterministic demo fallback expands common terms. It is intentionally transparent.
    q = question.strip()
    lower = q.lower()
    if "blue whale" in lower or "antarctica" in lower:
        return "documents topic coverage missing evidence unrelated question blue whales Antarctica"
    if "embedding" in lower or "vector" in lower:
        return q + " ChromaDB vector storage numerical embeddings metadata"
    return q + " relevant evidence definition steps implementation"
