import json
from agent.config import LLM_PROVIDER
from agent.llm import ask_llm

DIRECT_PATTERNS = (
    "what is 2 + 2", "what is 2+2", "what is 1 + 1", "hello", "hi",
    "what is the capital of france", "what is 5 * 5", "what is 5*5"
)

def route_question(question: str) -> dict:
    q = question.strip().lower()
    if any(p in q for p in DIRECT_PATTERNS) or q in {"thanks", "thank you"}:
        decision = {"route": "answer_directly", "reason": "This is a simple/general question that does not require the supplied documents."}
        return decision

    if LLM_PROVIDER == "gemini":
        prompt = f"""Classify the user question for a RAG system. Return only JSON with keys route and reason.
route must be needs_retrieval or answer_directly. Use needs_retrieval when the answer depends on supplied documents.
Question: {question}"""
        try:
            raw = ask_llm(prompt)
            start, end = raw.find("{"), raw.rfind("}")
            parsed = json.loads(raw[start:end+1])
            if parsed.get("route") in {"needs_retrieval", "answer_directly"}:
                return {"route": parsed["route"], "reason": parsed.get("reason", "LLM routing decision")}
        except Exception as exc:
            print(f"[WARN] LLM routing failed; using safe retrieval fallback: {exc}")
    return {"route": "needs_retrieval", "reason": "Question appears to depend on document-specific information."}
