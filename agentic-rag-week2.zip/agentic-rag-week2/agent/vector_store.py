import chromadb
from sentence_transformers import SentenceTransformer
from agent.config import CHROMA_DIR, COLLECTION_NAME, EMBEDDING_MODEL

class VectorStore:
    def __init__(self):
        print(f"[INFO] Loading embedding model: {EMBEDDING_MODEL}")
        self.embedder = SentenceTransformer(EMBEDDING_MODEL)
        self.client = chromadb.PersistentClient(path=str(CHROMA_DIR))
        self.collection = self.client.get_or_create_collection(
            COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
        )

    def reset(self):
        try:
            self.client.delete_collection(COLLECTION_NAME)
        except Exception:
            pass
        self.collection = self.client.get_or_create_collection(
            COLLECTION_NAME, metadata={"hnsw:space": "cosine"}
        )

    def add(self, items):
        if not items:
            return
        texts = [x["text"] for x in items]
        embeddings = self.embedder.encode(texts, normalize_embeddings=True).tolist()
        self.collection.add(
            ids=[x["id"] for x in items],
            documents=texts,
            embeddings=embeddings,
            metadatas=[{"source": x["source"], "chunk_index": x["chunk_index"]} for x in items],
        )

    def search(self, query: str, top_k: int = 4) -> list[dict]:
        count = self.collection.count()
        if count == 0:
            return []
        embedding = self.embedder.encode([query], normalize_embeddings=True)[0].tolist()
        result = self.collection.query(
            query_embeddings=[embedding], n_results=min(top_k, count),
            include=["documents", "metadatas", "distances"]
        )
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        distances = result.get("distances", [[]])[0]
        return [
            {"text": doc, "source": meta.get("source", "unknown"),
             "chunk_index": meta.get("chunk_index", -1), "distance": dist}
            for doc, meta, dist in zip(docs, metas, distances)
        ]
