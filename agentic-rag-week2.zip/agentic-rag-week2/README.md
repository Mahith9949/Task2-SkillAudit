# Week 2 — Agentic Retrieval Decisions

A small agentic RAG demo that decides whether a question needs retrieval, checks retrieved evidence, retries with rewritten queries when evidence is weak, and logs its decisions.

## Features
- Route each question to `answer_directly` or `needs_retrieval`.
- Retrieve the top-k matching chunks from a local ChromaDB collection.
- Self-check whether retrieved passages answer the question.
- Rewrite and retry up to two times if evidence is insufficient.
- Log each decision to the console and `logs/agent.log`.
- Includes five sample Markdown documents.
- Demo mode works without an API key using transparent rule-based logic. For real LLM decisions, configure Gemini in `.env`.

## Setup (Windows PowerShell)
```powershell
py -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
```

## Add your Gemini API key (optional but recommended)
Edit `.env`:
```env
LLM_PROVIDER=gemini
GEMINI_API_KEY=your_key_here
GEMINI_MODEL=gemini-2.5-flash
```
Keep `.env` private and never commit API keys. If no key is configured, `LLM_PROVIDER=demo` provides a deterministic demonstration of routing, retry logic, and logging. Demo mode is not an LLM.

## Build the index
```powershell
python ingest.py
```

## Run
```powershell
python main.py
```
Try these questions:
- `What is 2 + 2?` — should skip retrieval.
- `How does this project store embeddings?` — should retrieve document chunks.
- `What does the document say about blue whales in Antarctica?` — should demonstrate a retry because the supplied documents do not cover the question.

For one-shot runs:
```powershell
python main.py --question "What is 2 + 2?"
python main.py --question "How does this project store embeddings?"
python main.py --question "What does the document say about blue whales in Antarctica?"
```

## Project structure
```text
agentic-rag-week2/
├── data/documents/        # five sample documents
├── agent/
│   ├── router.py
│   ├── retriever.py
│   ├── self_check.py
│   ├── query_rewriter.py
│   ├── logger.py
│   └── llm.py
├── .env.example
├── .gitignore
├── requirements.txt
├── ingest.py
└── main.py
```

## Demo recording checklist
1. Show the project folder in VS Code.
2. Run `python ingest.py`.
3. Run `python main.py --question "What is 2 + 2?"` to show retrieval being skipped.
4. Run `python main.py --question "What does the document say about blue whales in Antarctica?"` to show the self-check and retry.
5. Show `logs/agent.log`.
6. Push the project to a public GitHub repository after checking `.env` contains no secret.
